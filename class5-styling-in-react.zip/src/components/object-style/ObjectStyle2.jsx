import React from 'react'
import { styles } from './style';

const ObjectStyle2 = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <div style={styles.Container}>
              <h2 style={styles.Header}>5) SHARING STYLES ACROS MANY COMPONENTS</h2>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ObjectStyle2